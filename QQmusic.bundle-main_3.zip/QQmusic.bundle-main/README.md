PLEX的QQ音乐刮削器，歌手、专辑信息来源于QQ音乐。

本地音乐需要有准确的id3音乐信息。

更多PLEX中文插件、教程请访问PLEX中文网 plexmedia.cn
