# WangYiYun.bundle
a PLEX music plugin get info form wangyiyun
